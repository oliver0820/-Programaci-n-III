﻿namespace Itla_Tv_.Common
{
    public static class ValidationHelper
    {
        public static bool IsValidString(string input)
        {
            return !string.IsNullOrEmpty(input) && input.Length > 2;
        }

        public static bool IsValidUrl(string url)
        {
            return Uri.IsWellFormedUriString(url, UriKind.Absolute);
        }
    }
}
