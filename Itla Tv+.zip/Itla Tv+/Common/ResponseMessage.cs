﻿

namespace Itla_Tv_.Common
{
    public class ResponseMessage
    {
        public bool Success { get; set; }
        public string Message { get; set; }
        public object? Data { get; set; } // Permitir que Data acepte valores nulos

        public ResponseMessage(bool success, string message, object? data = null) // Permitir que el parámetro data sea nullable
        {
            Success = success;
            Message = message;
            Data = data;
        }
    }
}
