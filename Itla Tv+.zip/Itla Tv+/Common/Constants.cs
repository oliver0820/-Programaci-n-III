﻿namespace Itla_Tv_.Common
{
    public static class Constants
    {
        public const string DefaultErrorMessage = "Ocurrió un error inesperado.";
        public const string NotFoundMessage = "El recurso solicitado no fue encontrado.";
    }
}
