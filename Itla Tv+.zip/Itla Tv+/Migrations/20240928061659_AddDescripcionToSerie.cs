﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Itla_Tv_.Migrations
{
    /// <inheritdoc />
    public partial class AddDescripcionToSerie : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Descripcion",
                table: "Series",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Descripcion",
                table: "Series");
        }
    }
}
