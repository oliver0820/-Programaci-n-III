﻿namespace Itla_Tv_.Entities
{
    public class Genero
    {
        public int Id { get; set; }
        public required string Nombre { get; set; } // Agregado el modificador 'required'

        public ICollection<Serie> SeriesPrimarias { get; set; } = new List<Serie>(); // Inicializar aquí
        public ICollection<Serie> SeriesSecundarias { get; set; } = new List<Serie>(); // Inicializar aquí

        // Constructor sin parámetros
        public Genero() { }

        // Constructor con parámetros
        public Genero(string nombre)
        {
            Nombre = nombre ?? throw new ArgumentNullException(nameof(nombre)); // Asegurarse de que no sea null
        }
    }
}
