﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Itla_Tv_.Entities
{
    public class Serie
    {
        public int Id { get; set; }

        [Required]
        public string Nombre { get; set; } = string.Empty;

        public string? Portada { get; set; }

        public string? EnlaceVideo { get; set; }

        public int ProductoraId { get; set; }

        [ForeignKey("ProductoraId")]
        public virtual Productora? Productora { get; set; } // Permitir que sea nulo

        public int GeneroPrimarioId { get; set; }

        [ForeignKey("GeneroPrimarioId")]
        public virtual Genero? GeneroPrimario { get; set; } // Permitir que sea nulo

        public int GeneroSecundarioId { get; set; }

        [ForeignKey("GeneroSecundarioId")]
        public virtual Genero? GeneroSecundario { get; set; } // Permitir que sea nulo

        [Required]
        public string Descripcion { get; set; } = string.Empty;
    }
}
