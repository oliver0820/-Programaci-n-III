﻿namespace Itla_Tv_.Entities
{
    public class Productora
    {
        public int Id { get; set; }

        public required string Nombre { get; set; }

        public ICollection<Serie>? Series { get; set; }
    }

}
