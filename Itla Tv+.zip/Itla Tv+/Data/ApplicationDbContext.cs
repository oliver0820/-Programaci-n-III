﻿using Itla_Tv_.Entities;
using Microsoft.EntityFrameworkCore;


 namespace ItlaTvPlus.Data


    {
        public class ApplicationDbContext : DbContext
        {
            public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
                : base(options)
            {
            }

            public DbSet<Serie> Series { get; set; }
            public DbSet<Productora> Productoras { get; set; }
            public DbSet<Genero> Generos { get; set; }

           protected override void OnModelCreating(ModelBuilder modelBuilder)
            {
                // Configurar la relación uno a muchos entre Genero y Serie
                modelBuilder.Entity<Serie>()
                    .HasOne(s => s.GeneroPrimario)
                    .WithMany(g => g.SeriesPrimarias)
                    .HasForeignKey(s => s.GeneroPrimarioId)
                    .OnDelete(DeleteBehavior.Restrict);

                modelBuilder.Entity<Serie>()
                    .HasOne(s => s.GeneroSecundario)
                    .WithMany(g => g.SeriesSecundarias)
                    .HasForeignKey(s => s.GeneroSecundarioId)
                    .OnDelete(DeleteBehavior.Restrict);
            }
        }
    }


