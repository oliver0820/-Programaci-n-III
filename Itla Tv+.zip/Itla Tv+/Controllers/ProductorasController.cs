﻿ // Asegúrate de que tu contexto esté bien referenciado
using Itla_Tv_.Entities; // Entidad Productora
using ItlaTvPlus.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace Itla_Tv_.Controllers
{
    public class ProductorasController : Controller
    {
        private readonly ApplicationDbContext _context;

        // Constructor que inyecta el contexto de la base de datos
        public ProductorasController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Productoras
        public async Task<IActionResult> Index()
        {
            // Obtener todas las productoras de la base de datos
            var productoras = await _context.Productoras.ToListAsync();
            return View(productoras);
        }

        // GET: Productoras/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var productora = await _context.Productoras
                .FirstOrDefaultAsync(m => m.Id == id);

            if (productora == null)
            {
                return NotFound();
            }

            return View(productora);
        }

        // GET: Productoras/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Productoras/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Nombre")] Productora productora)
        {
            if (ModelState.IsValid)
            {
                _context.Add(productora);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }

            return View(productora);
        }

        // GET: Productoras/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var productora = await _context.Productoras.FindAsync(id);
            if (productora == null)
            {
                return NotFound();
            }

            return View(productora);
        }

        // POST: Productoras/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Nombre")] Productora productora)
        {
            if (id != productora.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(productora);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ProductoraExists(productora.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }

                return RedirectToAction(nameof(Index));
            }

            return View(productora);
        }

        // GET: Productoras/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var productora = await _context.Productoras
                .FirstOrDefaultAsync(m => m.Id == id);

            if (productora == null)
            {
                return NotFound();
            }

            return View(productora);
        }

        // POST: Productoras/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var productora = await _context.Productoras.FindAsync(id);
            _context.Productoras.Remove(productora);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        // Verificar si la productora existe en la base de datos
        private bool ProductoraExists(int id)
        {
            return _context.Productoras.Any(e => e.Id == id);
        }
    }
}
