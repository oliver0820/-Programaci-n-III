﻿using DispensadorATM.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;



namespace DispensadorATM.Controllers
{
    public class DispensadorController : Controller
    {
        // Muestra el formulario para seleccionar el modo de dispensación
        public IActionResult SeleccionarModo()
        {
            return View();
        }

        // Procesa el modo de dispensación seleccionado
        [HttpPost]
        public IActionResult SeleccionarModo(string modoDispensacion)
        {
            TempData["ModoDispensacion"] = modoDispensacion; // Guardar el modo temporalmente
            return RedirectToAction("Retiro");
        }

        // Pantalla de retiro de dinero
        public IActionResult Retiro()
        {
            ViewBag.ModoDispensacion = TempData["ModoDispensacion"]?.ToString() ?? "eficiente";
            return View();
        }

        // Procesa la solicitud de retiro
        [HttpPost]
        public IActionResult Retiro(int cantidadRetiro, string modoDispensacion)
        {
            if (cantidadRetiro % 100 != 0)
            {
                ModelState.AddModelError("", "El monto debe ser un múltiplo de 100.");
                ViewBag.ModoDispensacion = modoDispensacion;
                return View();
            }

            var model = new DispensacionModel
            {
                ModoDispensacion = modoDispensacion,
                CantidadRetiro = cantidadRetiro
            };

            var billetes = model.CalcularBilletes();
            ViewBag.Billetes = billetes;

            return View("Resultado");
        }
    }
}