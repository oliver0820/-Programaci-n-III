﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;



namespace DispensadorATM.Models
{
    public class DispensacionModel
    {
        public string ModoDispensacion { get; set; } = "eficiente"; // Por defecto
        public int CantidadRetiro { get; set; }

        // Método para calcular la distribución de billetes
        public Dictionary<int, int> CalcularBilletes()
        {
            Dictionary<int, int> billetes = new Dictionary<int, int>();
            int[] denominaciones;

            switch (ModoDispensacion)
            {
                case "100-500":
                    denominaciones = new int[] { 500, 100 };
                    break;
                case "200-1000":
                    denominaciones = new int[] { 1000, 200 };
                    break;
                default: // Modo eficiente
                    denominaciones = new int[] { 1000, 500, 200, 100 };
                    break;
            }

            int montoRestante = CantidadRetiro;

            foreach (var billete in denominaciones)
            {
                int cantidadBilletes = montoRestante / billete;
                if (cantidadBilletes > 0)
                {
                    billetes[billete] = cantidadBilletes;
                    montoRestante -= cantidadBilletes * billete;
                }
            }

            return billetes;
        }
    }
}
